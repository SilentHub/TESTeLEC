export const ADMIN_PROFILE_ID = "admin";
export const ADMIN_PASSWORD = "bigggboss";

export const FOLDER_TYPE_CONTAINER = "folderContainer";
export const FOLDER_TYPE_PHRASES = "phraseContainer";
export const FOLDER_TYPE_SCENARIOS = "scenarioContainer";

export const EMOJI_LIST = [
  "🙂",
  "😊",
  "😎",
  "💼",
  "🏠",
  "💡",
  "❤️",
  "✅",
  "🚀",
  "⭐",
  "🤖",
  "🎮",
  "📚",
  "🎬",
  "🎵",
  "🔒",
  "💡",
  "💰",
  "📌",
  "📎",
  "💬",
  "✨",
];
